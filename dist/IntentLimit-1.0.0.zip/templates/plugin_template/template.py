__all__ = ["template"]

def template(handler, params):

	pass
